
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { WeatherData } from "../types";

export const fetchWeatherWithAI = async (location: string): Promise<WeatherData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Search for the current weather in ${location}. 
    Provide the current temperature, humidity, wind speed, and general condition.
    Also, provide a creative, friendly 2-sentence summary of the weather and a personalized recommendation for an activity today.
    Return the response as a valid JSON object with keys:
    city, temperature, condition, humidity, windSpeed, description, aiAdvice.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            city: { type: Type.STRING },
            temperature: { type: Type.STRING },
            condition: { type: Type.STRING },
            humidity: { type: Type.STRING },
            windSpeed: { type: Type.STRING },
            description: { type: Type.STRING },
            aiAdvice: { type: Type.STRING },
          },
          required: ["city", "temperature", "condition", "humidity", "windSpeed", "description", "aiAdvice"]
        }
      },
    });

    const jsonResult = JSON.parse(response.text || "{}");
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    const formattedSources = sources
      .filter((chunk: any) => chunk.web)
      .map((chunk: any) => ({
        title: chunk.web.title,
        web: { uri: chunk.web.uri }
      }));

    return {
      ...jsonResult,
      sources: formattedSources
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to fetch weather data. Please check your connection.");
  }
};

export const generateSpeech = async (text: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Read this weather advice warmly and helpfully: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("Could not generate audio");
  return base64Audio;
};
