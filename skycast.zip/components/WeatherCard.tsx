
import React, { useState } from 'react';
import { WeatherData } from '../types';
import { SunIcon, CloudIcon, RainIcon, WindIcon, HumidityIcon, SpeakerIcon } from './Icons';
import { generateSpeech } from '../services/geminiService';

interface WeatherCardProps {
  data: WeatherData;
}

const WeatherCard: React.FC<WeatherCardProps> = ({ data }) => {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const getIcon = (condition: string) => {
    const c = condition.toLowerCase();
    if (c.includes('sun') || c.includes('clear')) return <SunIcon />;
    if (c.includes('rain') || c.includes('drizzle')) return <RainIcon />;
    return <CloudIcon />;
  };

  const handleSpeak = async () => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const base64Audio = await generateSpeech(data.aiAdvice);
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const decode = (base64: string) => {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
        return bytes;
      };

      const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
        const dataInt16 = new Int16Array(data.buffer);
        const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
        return buffer;
      };

      const audioBuffer = await decodeAudioData(decode(base64Audio), audioCtx);
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      source.onended = () => setIsSpeaking(false);
      source.start();
    } catch (err) {
      console.error(err);
      setIsSpeaking(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <div className="glass rounded-[2rem] p-8 shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-4xl font-bold mb-1 tracking-tight">{data.city}</h2>
            <p className="text-xl text-white/70 font-medium capitalize">{data.condition}</p>
            <div className="mt-6 flex items-baseline">
              <span className="text-8xl font-black tracking-tighter drop-shadow-md">{data.temperature}</span>
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div className="p-6 bg-white/10 rounded-full mb-4 shadow-inner">
              {getIcon(data.condition)}
            </div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-white/40">{data.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-10">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex items-center space-x-4">
            <div className="text-blue-300"><HumidityIcon /></div>
            <div>
              <p className="text-[10px] text-white/40 uppercase font-black">Humidity</p>
              <p className="text-xl font-bold">{data.humidity}</p>
            </div>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5 flex items-center space-x-4">
            <div className="text-green-300"><WindIcon /></div>
            <div>
              <p className="text-[10px] text-white/40 uppercase font-black">Wind Speed</p>
              <p className="text-xl font-bold">{data.windSpeed}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="glass rounded-[1.5rem] p-6 border-l-4 border-yellow-400 shadow-xl animate-in fade-in slide-in-from-bottom-8 duration-1000">
        <div className="flex items-start space-x-5">
          <button 
            onClick={handleSpeak}
            disabled={isSpeaking}
            className={`w-12 h-12 flex-shrink-0 rounded-full flex items-center justify-center transition-all ${isSpeaking ? 'bg-yellow-400 text-slate-900 scale-110 shadow-lg shadow-yellow-400/50' : 'bg-white/10 text-yellow-400 hover:bg-white/20'}`}
          >
            <SpeakerIcon isPlaying={isSpeaking} />
          </button>
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <h3 className="font-black text-xs uppercase tracking-widest text-yellow-400">Gemini AI Assistant</h3>
              {isSpeaking && <span className="text-[10px] text-white/50 italic animate-pulse">Speaking...</span>}
            </div>
            <p className="text-white/90 leading-relaxed font-medium">
              "{data.aiAdvice}"
            </p>
          </div>
        </div>
      </div>

      {data.sources.length > 0 && (
        <div className="px-4">
          <p className="text-[10px] text-white/30 mb-2 uppercase tracking-[0.3em] font-black">Verification Sources</p>
          <div className="flex flex-wrap gap-2">
            {data.sources.slice(0, 3).map((source, i) => (
              <a 
                key={i} 
                href={source.web.uri} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[9px] bg-white/5 hover:bg-white/15 border border-white/5 transition-all px-3 py-1.5 rounded-full text-white/50 flex items-center"
              >
                <span className="truncate max-w-[120px]">{source.title}</span>
                <svg className="w-2 h-2 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherCard;
